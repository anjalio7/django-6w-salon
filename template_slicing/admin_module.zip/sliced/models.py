from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class user(AbstractUser):
    pass 

class services (models.Model):
    name = models.CharField(max_length=50)

class sub_services (models.Model):
    service_id = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    price = models.CharField(max_length=50)
    image = models.ImageField(upload_to = "images/")

class appointment (models.Model):
    user_id = models.CharField(max_length=50)
    subservice_id = models.CharField(max_length=50)
    bookingdate = models.CharField(max_length=50)
    time = models.CharField(max_length=50)
    status = models.CharField(max_length=50)

 