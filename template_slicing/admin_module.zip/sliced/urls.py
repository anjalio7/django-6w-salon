from django.urls import path
from . import views

urlpatterns = [
    path('home',views.index,name="home"),
    path('login',views.login_view,name="login"),
    path('logout',views.logout_view,name="logout"),
    path('addservices', views.add_service, name='add_services' ),
    path('allServices',views.allServices,name="allServices"),
    path('edittables/<int:id>',views.edittables,name="edittables"),
    path('deletetables/<int:id>',views.deletetables,name="deletetables"),
    path('subServices',views.subServices,name="subServices"),
    path('allsubServices',views.allsubServices,name="allsubServices"),
    path('edittables/<int:id>',views.edittables,name="edittables"),
    path('deletetables/<int:id>',views.deletetables,name="deletetables"),
]