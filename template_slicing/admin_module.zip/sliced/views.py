from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponse, HttpResponseRedirect
from django.core.exceptions import ValidationError
# from . models import user, services, sub_services, appointment
from .models import * 
# Create your views here.
def index(request):
    return render(request, 'sliced/layout.html')

def login_view(request):
    if request.method == "POST":
        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username,
        password=password)
        # Check if authentication successful
        if user is not None:
            if user.is_superuser:
                login(request, user)
                return HttpResponseRedirect(reverse("home"))
            else:
                return render(request, "sliced/login.html", {
            "message": "Invalid username and/or password."
        })
        else:
            return render(request, "sliced/login.html", {
            "message": "Invalid username and/or password."
        })
    else:
        return render(request, "sliced/login.html")

def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse('login'))

def add_service(request):
    if request.method =="POST":
        serName = request.POST['name']
        obj = services(name = serName)
        obj.save()
        return HttpResponseRedirect(reverse('allServices'))
    else:
        return render(request, 'sliced/add_services.html')   

def allServices(request):
    allSer = services.objects.all()
    return render(request, 'sliced/table.html', {'data': allSer})


def deletetables(request,id):
    # table = allServices.objects.get(id = table)
    selService = services.objects.get(id = id)
    selService.delete()
    return HttpResponseRedirect(reverse('allServices'))

def edittables(request,id):
    selService = services.objects.get(id = id)

    if request.method == "POST":
        service = request.POST['name']

        selService.name = service
        selService.save()
        return HttpResponseRedirect(reverse('allServices'))
    else:
        return render (request, 'sliced/editService.html',{'data':selService})

def subServices(request):
    subSer = services.objects.all()
    return render(request, 'sliced/sub_services.html', {'data': subSer})

def allsubServices(request):
    allsubSer = services.objects.all()
    return render(request, 'sliced/table.html', {'data': allsubSer})

def deletetables(request,id):
    # table = allServices.objects.get(id = table)
    subService = services.objects.get(id = id)
    subService.delete()
    return HttpResponseRedirect(reverse('subServices'))

def edittables(request,id):
    subService = services.objects.get(id = id)

    if request.method == "POST":
        service = request.POST['name']

        subService.name = service
        subService.save()
        return HttpResponseRedirect(reverse('subServices'))
    else:
        return render (request, 'sliced/sub_Services.html',{'data':subService})

